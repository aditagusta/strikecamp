<!-- main content -->
<!-- page Title -->
<?php $__env->startSection('page-title','Data Jadwal'); ?>
<!-- Page Content -->
<?php $__env->startSection('content'); ?>

<div class="row mt-3">
    <div class="col-sm-12 col-md-12">
        
        <button class="btn btn-sm btn-primary" onclick="tambah()"><i class="fa fa-plus"></i> Jadwal</button>
        <table id="table" class="table table-striped table-bordered table-responsive">
            <thead>
                <tr style="text-align: center;">
                    <th style="width: 2%;">No</th>
                    <th>Tanggal</th>
                    <th>Jam</th>
                    <th>Trainer</th>
                    <th style="width: 20%;">Aksi</th>
                </tr>
            </thead>
            <tbody>
                
                <?php $__currentLoopData = $jadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $itemjadwal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($no+1); ?></td>
                    <td><?php echo e(tanggal_indonesia($itemjadwal['jadwal'])); ?></td>
                    <td>
                        
                        
                        <?php echo e($itemjadwal['jam']); ?>

                    </td>
                    <td><?php echo e($itemjadwal['nama_trainer']); ?></td>
                    <td>
                        <div class="row">
                            <div class="col-sm-12 col-md-6">
                                <form method="POST" action="<?php echo e(route('removejadwal', [$itemjadwal['id_jadwal']])); ?>">
                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>
                                    <button class="btn btn-sm btn-danger" type="submit">Hapus</button>
                                </form>
                            </div>
                            <div class="col-sm-12 col-md-6">
                                <button type="button" onclick="edited('<?php echo e($itemjadwal['id_jadwal']); ?>','<?php echo e($itemjadwal['jadwal']); ?>','<?php echo e($itemjadwal['id_trainer']); ?>')" class="btn btn-sm btn-warning">Ubah</button>
                            </div>
                            
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal Tambah -->
<div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Form Tambah Data</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <form action="<?php echo e(route('addjadwal')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="">Tanggal</label>
                <input type="hidden" class="form-control" id="id_user" name="id_user" value="<?php echo e(Auth::guard('pusat')->user()->id_user); ?>">
                <input type="hidden" class="form-control" id="id_cabang" name="id_cabang" value="<?php echo e(Auth::guard('pusat')->user()->id_cabang); ?>">
                <input type="date" class="form-control" id="jadwal" name="jadwal" reqiured>
            </div>
            <div class="form-group">
                <label for="">Trainer</label>
                <select name="trainer" id="trainer" class="form-control" required>
                    <option value="">-- Silahkan Pilih --</option>
                    <?php $__currentLoopData = $trainer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemtrainer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($itemtrainer->id_trainer); ?>"><?php echo e($itemtrainer->nama_trainer); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="row">
                <?php $__currentLoopData = $jam; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemjam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-3">
                    <input type="checkbox" name="jam[]" value="<?php echo e($itemjam->id_jam); ?>">&nbsp&nbsp&nbsp<?php echo e($itemjam->jam); ?>

                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <button type="submit" class="btn btn-primary" id="simpan">Simpan</button>
          </form>
        </div>
      </div>
    </div>
</div>



<div class="modal fade" id="editModal" data-backdrop="static" data-keyboard="false" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Form Ubah Data</h5>
          <button type="button" class="close" onclick="bersih()" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <form action="<?php echo e(route('editjadwal')); ?>" method="POST">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="">Tanggal</label>
                <input type="hidden" class="form-control" id="id_jadwal" name="id_jadwal">
                <input type="hidden" class="form-control" id="user_" name="user_" value="<?php echo e(Auth::guard('pusat')->user()->id_user); ?>">
                <input type="hidden" class="form-control" id="cabang_" name="cabang_" value="<?php echo e(Auth::guard('pusat')->user()->id_cabang); ?>">
                <input type="date" class="form-control" id="jadwal_" name="jadwal_" required>
            </div>
            <div class="form-group">
                <label for="">Trainer</label>
                <select name="trainer_" id="trainer_" class="form-control" required>
                    <option value="">-- Silahkan Pilih --</option>
                    <?php $__currentLoopData = $trainer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemtrainer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($itemtrainer->id_trainer); ?>"><?php echo e($itemtrainer->nama_trainer); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="row">
                <?php $__currentLoopData = $jam; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemjam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-3">
                    <input type="checkbox" name="jam[]" id="<?php echo e($itemjam->id_jam); ?>" value="<?php echo e($itemjam->id_jam); ?>">&nbsp&nbsp&nbsp<?php echo e($itemjam->jam); ?>

                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <button type="submit" class="btn btn-primary">Simpan</button>
          </form>
        </div>
      </div>
    </div>
</div>

<script>
    $('#table').DataTable();
    function tambah()
    {
        $('#addModal').modal('show')
    }

    function edited(idjadwal,jadwal,idtrainer)
    {
        console.log(idjadwal);
        axios.post("<?php echo e(url('/api/schedule')); ?>",{
            'id_jadwal':idjadwal
        }).then(function(res){
            var cek = res.data;
            // console.log(cek);
            if(cek[0].id_jam == null)
            {
                var tes = cek[0].id_jam
            }else{
                var tes = cek[0].id_jam.split(",")
            }
            console.log(tes);

        // Cara 1
            if(tes != null)
            {
                for(var i = 0; i < tes.length; i++){
                document.getElementById(tes[i]).checked = true;
                }
            } else {
                var list_jam = document.getElementsByName("jam[]");
                // reset centang jam
                for (var x = 0; x < list_jam.length; x++) {
                    list_jam[x].checked = false;
                }
            }
            $('#id_jadwal').val(idjadwal)
            $('#jadwal_').val(jadwal)
            $('#trainer_').val(idtrainer)
            $('#editModal').modal('show')
        })
    }

    function bersih()
    {
        $('[name="jam[]"]').prop('checked',false)
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\strikecamp\resources\views/pages/admin/jadwal/index.blade.php ENDPATH**/ ?>