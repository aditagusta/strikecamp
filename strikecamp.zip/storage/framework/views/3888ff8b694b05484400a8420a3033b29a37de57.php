<div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
    <div class="menu_section">
        <h3>General</h3>
        <ul class="nav side-menu">
            <li><a href="<?php echo e(url('/')); ?>"><i class="fa fa-home"></i> Home</a>
            </li>
            <li><a><i class="fa fa-database"></i> Data Approve <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                    <li><a href="<?php echo e(route('approve_order')); ?>">Order Paket</a></li>
                </ul>
            </li>
            <li><a><i class="fa fa-database"></i> Data Master <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                    <li><a href="<?php echo e(route('banner')); ?>">Data Banner</a></li>
                    <li><a href="<?php echo e(route('katalog')); ?>">Data Katalog</a></li>
                    <li><a href="<?php echo e(route('cabang')); ?>">Data Cabang</a></li>
                    <li><a href="<?php echo e(route('paket')); ?>">Data Paket</a></li>
                    <li><a href="<?php echo e(route('user')); ?>">Data Member Cabang</a></li>
                </ul>
            </li>
            <li><a href="<?php echo e(route('contact')); ?>"><i class="fa fa-home"></i> Contact Cabang</a>
            </li>
            <li><a href="<?php echo e(url('laporan/order')); ?>"><i class="fa fa-home"></i> Laporan Order Paket</a>
            </li>
        </ul>
    </div>


</div>
<?php /**PATH D:\xampp\htdocs\strikecamp\resources\views/component/sidebar.blade.php ENDPATH**/ ?>