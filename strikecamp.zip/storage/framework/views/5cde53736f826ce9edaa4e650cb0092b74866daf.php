<!-- main content -->
<!-- page Title -->
<?php $__env->startSection('page-title','Approve Order Paket'); ?>
<!-- Page Content -->
<?php $__env->startSection('content'); ?>
<div class="row mt-3">
    <div class="col-sm-12 col-md-12" id="table">

    </div>
</div>
<script>
    $(document).ready(function () {
        $('#table').load("<?php echo e(route('table_order_approve')); ?>")
    });

    function simpan(id)
    {
        var status = $('#approve').val()
        var idorder = id
        axios.post("<?php echo e(url('/api/approve/order')); ?>",{
            id_order:id,
            status:status,
        }).then(function(res){
            var data = res.data
            console.log(data.status)
            if(data.status == 200)
            {
                toastr.info(data.message)
                $('#table').load("<?php echo e(route('table_order_approve')); ?>")
            }else{
                toastr.info("Pemeriksaan Tidak Valid")
            }
        })
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\strikecamp\resources\views/pages/transaksi/approve/index_order.blade.php ENDPATH**/ ?>