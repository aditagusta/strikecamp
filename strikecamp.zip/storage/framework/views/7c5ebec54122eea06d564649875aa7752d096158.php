<label for="">Silahkan Pilih Jam</label>
<br>
<div class="row">
    <?php $__currentLoopData = $agenda; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-sm-2">
        <input type="checkbox" name="jam[]" id="<?php echo e($a->jam); ?>" value="<?php echo e($a->jam); ?>">&nbsp&nbsp&nbsp<?php echo e($a->jam); ?>

    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php /**PATH D:\xampp\htdocs\strikecamp\resources\views/pages/transaksi/booking/agenda.blade.php ENDPATH**/ ?>