<label for="">Silahkan Pilih Jam</label>
<br>
<div class="row">
    
    <?php $__currentLoopData = $agenda[0]['id_jam']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $datass = DB::table('tbl_jam')->where('id_jam', $a)->first();
            echo  "<div class='col-sm-2'>
                    <input type='checkbox' name='jam[]' id=". $datass->id_jam ." value=". $datass->id_jam .">&nbsp&nbsp&nbsp". $datass->jam ."
                   </div>";
        ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php /**PATH D:\xampp\htdocs\strikecamp\resources\views/pages/transaksi/booking/agenda.blade.php ENDPATH**/ ?>