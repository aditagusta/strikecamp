<link rel="stylesheet" href="//cdn.datatables.net/1.10.22/css/jquery.dataTables.min.css">
<script src="//cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js"></script>
<table id="myTable" class="table table-striped table-bordered table-responsive">
    <thead>
        <tr style="text-align: center;">
            <th style="width: 2%">No</th>
            <th style="width: 20%">Nama Member</th>
            <th style="width: 10%">Jumlah Paket</th>
            <th style="width: 10%">Nama Cabang</th>
            <th style="width: 20%">Tanggal Order</th>
            <th style="width: 20%">Status</th>
            <th style="width: 18%">Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($no+1); ?></td>
            <td><?php echo e($item->nama_member); ?></td>
            <td><?php echo e($item->nama_paket); ?></td>
            <td><?php echo e($item->nama_cabang); ?></td>
            <td><?php echo e(tanggal_indonesia($item->tanggal_order)); ?></td>
            <td>
                <?php if($item->status == 0): ?>
                <div class="alert alert-warning" align=center role="alert">
                    PENDING
                </div>
                <?php endif; ?>
            </td>
            <td>
                <div class="row">
                    <?php if($item->status == 0): ?>
                    <div class="col-md-6 col-sm-12">
                        <button class="btn btn-sm btn-warning" onclick="edited('<?php echo e($item->id_order); ?>')">Ubah</button>
                    </div>
                    <div class="col-md-6 col-sm-12">
                        <button class="btn btn-sm btn-danger" onclick="deleted('<?php echo e($item->id_order); ?>')">Hapus</button>
                    </div>
                    <?php endif; ?>
                </div>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<script>
    $('#myTable').DataTable();
</script>
<?php /**PATH D:\xampp\htdocs\strikecamp\resources\views/pages/transaksi/order/table.blade.php ENDPATH**/ ?>