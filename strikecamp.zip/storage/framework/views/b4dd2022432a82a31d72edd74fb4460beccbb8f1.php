<!-- main content -->
<!-- page Title -->
<?php $__env->startSection('page-title','Data Booking'); ?>
<!-- Page Content -->
<?php $__env->startSection('content'); ?>
<div class="row mt-3">
    <div class="col-sm-12 col-md-12">
        <div class="mb-2">
            <div class="card">
                <div class="card-body">
                    

                    <?php if($message = Session::get('success')): ?>
                    <div class="alert alert-success alert-block">
                      <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong><?php echo e($message); ?></strong>
                    </div>
                    <?php endif; ?>
                    <form action="<?php echo e(route('addbooking')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-sm-12 col-md-6">
                                <div class="form-group">
                                    <label for="">Tanggal Latihan</label>
                                    <select name="tanggal" id="tanggal" class="form-control" onchange="hari()">
                                        <option value="">-- Silahkan Pilih --</option>
                                        <?php $__currentLoopData = $jadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemjadwal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($itemjadwal->id_jadwal); ?>"><?php echo e(tanggal_indonesia($itemjadwal->jadwal)); ?> - <?php echo e($itemjadwal->nama_trainer); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="row">
                                    <div class="col-sm-12 col-md-6">
                                        <div class="form-group">
                                            <label for="">Member</label>
                                            <select name="member" id="member" class="form-control" onchange="members()">
                                                <option value="">-- Silahkan Pilih --</option>
                                                <?php $__currentLoopData = $member; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemmember): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($itemmember->id_member); ?>"><?php echo e($itemmember->nama_member); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-sm-12 col-md-6">
                                        <div class="form-group">
                                            <label for="">Sisa Paket</label>
                                            <input type="text" class="form-control" id="paket" name="paket" readonly>
                                        </div>
                                    </div>
                                </div>
                                <button class="btn btn-sm btn-success" type="submit">Simpan</button>
                            </div>
                            <div class="col-sm-12 col-md-6" id="agenda">

                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <table id="myTable" class="table table-striped table-bordered table-responsive">
            <thead>
                <tr style="text-align: center;">
                    <th style="width: 2%">No</th>
                    <th style="width: 20%">Nama Member</th>
                    <th style="width: 20%">Jam</th>
                    <th style="width: 20%">Tanggal Latihan</th>
                    <th style="width: 18%">Aksi</th>
                </tr>
            </thead>
            <tbody>
               <?php $__currentLoopData = $booking; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $bk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($no+1); ?></td>
                    <td><?php echo e($bk['nama_member']); ?></td>
                    <td>
                        
                        <?php echo e($bk['jam']); ?>

                    </td>
                    <td><?php echo e(tanggal_indonesia($bk['jadwal'])); ?></td>
                    <td>
                        <div class="row">
                            <div class="col-sm-12 col-md-12">
                                <form method="POST" action="<?php echo e(route('removebooking', [$bk['id_booking']])); ?>">
                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>
                                    <button class="btn btn-sm btn-danger" type="submit">Hapus</button>
                                </form>
                            </div>
                        </div>
                    </td>
                </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<script>
    function hari()
    {
        var id = $('#tanggal').val()
        $('#agenda').load("<?php echo e(route('tableagenda')); ?>/" + id)
        axios.post("<?php echo e(url('/api/cekjam')); ?>",{
            'id_jadwal':id
        }).then(function(res){
            var cek = res.data;
            // console.log(cek[0].id_jam)
            console.log(cek);
            if(cek == '')
            {
                var tes = ''
            }else{
                var tes = cek[0].id_jam.split(",")
            }
            console.log(tes);

            if(tes != '')
            {
                for(var i = 0; i < tes.length; i++){
                    document.getElementById(tes[i]).checked = true;
                    document.getElementById(tes[i]).disabled = true;
                }
            } else {
                var list_jam = document.getElementsByName("jam[]");
                // reset centang jam
                for (var x = 0; x < list_jam.length; x++) {
                    list_jam[x].checked = false;
                }
            }
        })
    }

    function members()
    {
       var id = $('#member').val()
       axios.get("<?php echo e(url('/api/cekpaket')); ?>/"+id)
        .then(function(res){
            var data = res.data
            console.log(data)
            $('#paket').val(data.sisa_paket)
        })
    }

    $('#myTable').DataTable()
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\strikecamp\resources\views/pages/transaksi/booking/index.blade.php ENDPATH**/ ?>