<!-- main content -->
<!-- page Title -->
<?php $__env->startSection('page-title','Profile Anda'); ?>
<!-- Page Content -->
<?php $__env->startSection('content'); ?>
<div class="row mt-3">
    <div class="col-sm-12 col-md-12">
        <div class="row">
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-12 col-md-6 mt-2">
                <div class="card">
                    <div class="card-header"><h4><?php echo e($item->nama_user); ?></h4></div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-4">
                                <img src="/images/<?php echo e($item->gambar_cabang); ?>" class="img-fluid" alt="">
                            </div>
                            <div class="col-md-8">
                                Informasi User
                                <table>
                                    <tr>
                                        <td><h5>Username</h5></td>
                                        <td><h5>:</h5></td>
                                        <td><h5><?php echo e($item->username); ?></h5></td>
                                    </tr>
                                    <tr>
                                        <td><h5>Password</h5></td>
                                        <td><h5>:</h5></td>
                                        <td><h5><?php echo e($item->password1); ?></h5></td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\strikecamp\resources\views/pages/admin/profile/index.blade.php ENDPATH**/ ?>