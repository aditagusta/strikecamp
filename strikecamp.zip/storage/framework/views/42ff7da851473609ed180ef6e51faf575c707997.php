<!-- main content -->
<!-- page Title -->
<?php $__env->startSection('page-title','Laporan Order Paket'); ?>
<!-- Page Content -->
<?php $__env->startSection('content'); ?>
<div class="row mt-3">
    <div class="col-sm-12 col-md-12">
        <table id="myTable" class="table table-striped table-bordered table-responsive" style="width: 100%">
            <thead>
                <tr>
                    <th >No</th>
                    <th style="width: 25%">Nama Member</th>
                    <th style="width: 15%">Cabang</th>
                    <th style="width: 20%">Nama Paket</th>
                    <th style="width: 25%">Tanggal Pembelian</th>
                    <th style="width: 30%">Harga</th>
                </tr>
            </thead>
            <tbody>
                <?php $total = 0 ;?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $total += $i->harga ;?>
                <tr>
                    <td><?php echo e($no+1); ?></td>
                    <td><?php echo e($i->nama_member); ?></td>
                    <td><?php echo e($i->nama_cabang); ?></td>
                    <td><?php echo e($i->nama_paket); ?></td>
                    <td><?php echo e(tanggal_indonesia($i->tanggal_order)); ?></td>
                    <td>Rp. <?php echo e(number_format($i->harga)); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
                <th colspan="5">Total Order</th>
                <td>Rp. <?php echo e(number_format($total)); ?></td>
            </tfoot>
        </table>
    </div>
</div>
<script>
    $(document).ready(function () {
        $('#myTable').DataTable()
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\strikecamp\resources\views/pages/report/orderpaket/index.blade.php ENDPATH**/ ?>