<table id="myTable" class="table table-striped table-bordered table-responsive">
    <thead>
        <tr style="text-align: center;">
            <th style="width: 2%;">No</th>
            <th style="width: 20%;">Nama Paket</th>
            <th style="width: 20%;">Jumlah</th>
            <th style="width: 48%;">Harga</th>
            <th style="width: 10%;">Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($no+1); ?></td>
            <td><?php echo e($item->nama_paket); ?></td>
            <td><?php echo e($item->jumlah); ?></td>
            <td>Rp. <?php echo e(number_format($item->harga)); ?></td>
            <td>
                <div class="row">
                    <div class="col-sm-12 col-md-6">
                        <button class="btn btn-sm btn-warning" type="button" onclick="edited('<?php echo e($item->id_paket); ?>')">Ubah</button>
                    </div>
                    <div class="col-sm-12 col-md-6">
                        <button class="btn btn-sm btn-danger" type="button" onclick="deleted('<?php echo e($item->id_paket); ?>')">Hapus</button>
                    </div>
                </div>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<script>
    $(document).ready(function () {
        $('#myTable').DataTable()
    });
</script>
<?php /**PATH D:\xampp\htdocs\strikecamp\resources\views/pages/admin/paket/table.blade.php ENDPATH**/ ?>