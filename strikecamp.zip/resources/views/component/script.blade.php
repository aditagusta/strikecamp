<!-- Bootstrap -->
<script src="{{asset('/assetsbe/vendors/bootstrap/dist/js/bootstrap.bundle.min.js')}}"></script>
<!-- FastClick -->
<script src="{{asset('/assetsbe/vendors/fastclick/lib/fastclick.js')}}"></script>
<!-- NProgress -->
<script src="{{asset('/assetsbe/vendors/nprogress/nprogress.js')}}"></script>
<!-- Chart.js -->
<script src="{{asset('/assetsbe/vendors/Chart.js/dist/Chart.min.js')}}"></script>
<!-- jQuery Sparklines -->
<script src="{{asset('/assetsbe/vendors/jquery-sparkline/dist/jquery.sparkline.min.js')}}"></script>
<!-- morris.js -->
<script src="{{asset('/assetsbe/vendors/raphael/raphael.min.js')}}"></script>
<script src="{{asset('/assetsbe/vendors/morris.js/morris.min.js')}}"></script>
<!-- gauge.js -->
<script src="{{asset('/assetsbe/vendors/gauge.js/dist/gauge.min.js')}}"></script>
<!-- bootstrap-progressbar -->
<script src="{{asset('/assetsbe/vendors/bootstrap-progressbar/bootstrap-progressbar.min.js')}}"></script>
<!-- Skycons -->
<script src="{{asset('/assetsbe/vendors/skycons/skycons.js')}}"></script>
<!-- Flot -->
<script src="{{asset('/assetsbe/vendors/Flot/jquery.flot.js')}}"></script>
<script src="{{asset('/assetsbe/vendors/Flot/jquery.flot.pie.js')}}"></script>
<script src="{{asset('/assetsbe/vendors/Flot/jquery.flot.time.js')}}"></script>
<script src="{{asset('/assetsbe/vendors/Flot/jquery.flot.stack.js')}}"></script>
<script src="{{asset('/assetsbe/vendors/Flot/jquery.flot.resize.js')}}"></script>
<!-- Flot plugins -->
<script src="{{asset('/assetsbe/vendors/flot.orderbars/js/jquery.flot.orderBars.js')}}"></script>
<script src="{{asset('/assetsbe/vendors/flot-spline/js/jquery.flot.spline.min.js')}}"></script>
<script src="{{asset('/assetsbe/vendors/flot.curvedlines/curvedLines.js')}}"></script>
<!-- DateJS -->
<script src="{{asset('/assetsbe/vendors/DateJS/build/date.js')}}"></script>
<!-- bootstrap-daterangepicker -->
<script src="{{asset('/assetsbe/vendors/moment/min/moment.min.js')}}"></script>
<script src="{{asset('/assetsbe/vendors/bootstrap-daterangepicker/daterangepicker.js')}}"></script>

<!-- Custom Theme Scripts -->
<script src="{{asset('/assetsbe/build/js/custom.min.js')}}"></script>

<!-- iCheck -->
{{-- <script src="{{asset('/assetsbe/vendors/iCheck/icheck.min.js')}}"></script> --}}

{{-- Datatable --}}
<script type="text/javascript" src="https://cdn.datatables.net/v/bs4/dt-1.10.21/datatables.min.js"></script>
<!-- selectpicker -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.18/js/bootstrap-select.min.js" integrity="sha512-yDlE7vpGDP7o2eftkCiPZ+yuUyEcaBwoJoIhdXv71KZWugFqEphIS3PU60lEkFaz8RxaVsMpSvQxMBaKVwA5xg==" crossorigin="anonymous"></script>
<!-- live serch -->
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>
